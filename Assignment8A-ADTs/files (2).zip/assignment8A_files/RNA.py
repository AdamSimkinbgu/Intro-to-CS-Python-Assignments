
class RNA:
    def __init__(self, sequence):
        pass

    def calculate_mass(self):
        pass

    def mutate(self, mutation_position, nucleotide_letter):
        pass

    def RNA_generator(self):
        pass

    def validate_sequence(self):
        pass
