
class DNA:
    def __init__(self, sequence):
        pass

    def complement(self):
        pass

    def calculate_mass(self):
        pass

    def mutate(self, mutation_type, mutation_position, nucleotides_mutation):
        pass
